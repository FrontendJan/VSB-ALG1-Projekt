var indexSectionsWithContent =
{
  0: "gims",
  1: "g",
  2: "gm",
  3: "gims"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

