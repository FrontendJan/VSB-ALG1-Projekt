var searchData=
[
  ['cols_0',['cols',['../class_grid.html#add88adc7b2e7ff3c6867f6ebca42e260',1,'Grid']]]
];
