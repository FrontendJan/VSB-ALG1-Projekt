var searchData=
[
  ['simulaterot_7',['simulateRot',['../classGrid.html#a163581f6542b71356b65adf51deba427',1,'Grid']]]
];
